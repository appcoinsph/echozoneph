# CSS Christmas Tree with Lights

A Pen created on CodePen.io. Original URL: [https://codepen.io/FlyBirds-Box/pen/qqgzqe](https://codepen.io/FlyBirds-Box/pen/qqgzqe).

Pure CSS Animated Christmas Tree